document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("predictForm");
    const resultDiv = document.getElementById("predictionResult");
    const locationSelect = document.getElementById("location");

    // Load locations
    fetch("/get_location_names")
        .then(res => res.json())
        .then(data => {
            if (data.locations) {
                data.locations.forEach(loc => {
                    const option = document.createElement("option");
                    option.value = loc;
                    option.textContent = loc;
                    locationSelect.appendChild(option);
                });
            }
        });

    // Handle form submission
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const sqft = parseFloat(document.getElementById("sqft").value);
        const bhk = parseInt(document.getElementById("bhk").value);
        const bath = parseInt(document.getElementById("bath").value);
        const location = locationSelect.value;

        fetch("/predict_home_price", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ total_sqft: sqft, bhk: bhk, bath: bath, location: location })
        })
        .then(res => res.json())
        .then(data => {
            resultDiv.style.display = "block";
            resultDiv.textContent = `Estimated Price: ₹ ${data.estimated_price} Lakhs`;
        })
        .catch(err => {
            resultDiv.style.display = "block";
            resultDiv.textContent = "Something went wrong!";
        });
    });
});
