# used  jupyter note books for data processng and model bulding and to buiild model used libraries like flask pickle pandas numpy matplotlib...etc
,python,pycharm flask and jsonify pickel file of data model ,html css for Ui used cmd to run the project in the local server. 
 
# python server.py
# final output:
output:
Microsoft Windows [Version 10.0.17134.1550]
(c) 2018 Microsoft Corporation. All rights reserved.

C:\Users\ssc\Desktop\projects\Bengaluru_House_Data\BHP\server>python server.py
Starting Flask Server For Home Price Prediction>>>>
loading saved artifacts....Start
loading artifacts.......Done.
 * Serving Flask app 'server'
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
127.0.0.1 - - [27/May/2024 20:49:30] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:49:33] "GET /bgw.js HTTP/1.1" 404 -
127.0.0.1 - - [27/May/2024 20:49:33] "GET /effect.css HTTP/1.1" 404 -
127.0.0.1 - - [27/May/2024 20:49:56] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:49:56] "GET /effect.css HTTP/1.1" 404 -
127.0.0.1 - - [27/May/2024 20:49:56] "GET /bgw.js HTTP/1.1" 404 -

C:\Users\ssc\Desktop\projects\Bengaluru_House_Data\BHP\server>python server.py
Starting Flask Server For Home Price Prediction>>>>
loading saved artifacts....Start
loading artifacts.......Done.
 * Serving Flask app 'server'
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
127.0.0.1 - - [27/May/2024 20:52:07] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:52:08] "GET /favicon.ico HTTP/1.1" 404 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:52:19] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:54:11] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:54:15] "POST /predict_home_price HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:57:56] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:57:59] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:58:00] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:58:12] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:58:12] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:58:12] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [27/May/2024 20:58:13] "GET / HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:15] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:18] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:24] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:33] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:47] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 20:59:48] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:00:03] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:00:12] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:00:15] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:00:23] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:00:33] "POST /predict_home_price HTTP/1.1" 200 -
C:\Users\ssc\AppData\Local\Programs\Python\Python312\Lib\site-packages\sklearn\base.py:465: UserWarning: X does not have valid feature names, but LinearRegression was fitted with feature names
  warnings.warn(
127.0.0.1 - - [27/May/2024 21:01:09] "POST /predict_home_price HTTP/1.1" 200 -

C:\Users\ssc\Desktop\projects\Bengaluru_House_Data\BHP\server>